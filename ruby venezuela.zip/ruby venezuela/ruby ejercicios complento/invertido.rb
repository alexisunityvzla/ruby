#!/urs/bin/env ruby

puts "primer numero:"

n1=gets.to_i

puts "segundo numero:"

n2=gest.to_i

puts "tercer numero:"

rev1=gets.to_i

puts "cuarto numero:"

rev2=gest.to_i

rev1=n1/10;
rev1=n1%10;
rev2=n1/10;
rev2=n2%10;

print "primer numero:",n1;
print "segundo numero:",n2;
print "tercer numero:",rev1;
print "cuarto numero:",rev2;

end