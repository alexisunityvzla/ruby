#!/urs/bin/env ruby

puts "digite las nota del alumno:"

puts "selecciona el primer  numero de nota:"

nota = gets.to_i

if  nota < = 12.09 

 puts "la nota es correcta!"

else

puts " la nota no es correcta!"

end 

 