#!/urs/bin/env ruby

puts "escriba un numero entero:"

num=gets.to_i

puts""

if num < 100
puts "el numero que ha escrito es menor a 100"
else
puts "el numero que ha escrito es mayor a 100"

puts "el numero 100",num;

end
