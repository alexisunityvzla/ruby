#!/urs/bin/env ruby

puts "ingrese un numero:";

res=gets.to_i


if res >5

 puts "suficiente";

 else

  puts "no suficiente";

 
end

puts "el resulltado del cuadradro es:",res;
