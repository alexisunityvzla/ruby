#!/urs/bin/env ruby

while x <= 5

 print "ingrese un numero:"
 valor1=gets.to_i
 suma=suma+1;
 x=x+1;

 print "la suma de los valores es:",suma;

end 
