#!/urs/bin/env ruby

puts "selecciona un numero:"

n1=gets.to_i

if n1%2==0

 puts " es par"

else

 puts "es impar"

 
end
