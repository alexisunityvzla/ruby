#!/urs/bin/env ruby

print "Cuantas personas hay:"

n=gets.to_i
x=1
suma=0
while x &lt ;=n
	print "Ingrese la altura:"
	altura=gets.to_f
	suma=suma+altura
	x=x+1
end

 promedio=suma/n
 print "Altura promedio:",promedio

 



