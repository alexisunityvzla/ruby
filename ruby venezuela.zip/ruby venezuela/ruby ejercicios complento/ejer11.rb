#!/urs/bin/env ruby


puts "ingrese un numero:"

n1=gets.to_i
while n1 > 2


	puts "ingrese otro numero:"

	n1=gets.to_i

	puts "el resultado sera es:",n1;


end
