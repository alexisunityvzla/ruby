#!/urs/bin/env ruby

puts "instroduzca un numero:"

 num=gets.to_i

while num != 0

  if num >= 0

  puts "positivos"

  else

  puts " negativos"

puts " instroduzca otro numero:"

 num = gets.to_i

 end

end