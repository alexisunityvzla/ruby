#!/urs/bin/env ruby

puts "me gusta"+"el pastel de manzana"
