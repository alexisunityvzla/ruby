#!/urs/bin/env ruby
x = l
termino = ll
while x &lt;= 25
print termino, " - "
x = x+ l
termino = termino +ll
end