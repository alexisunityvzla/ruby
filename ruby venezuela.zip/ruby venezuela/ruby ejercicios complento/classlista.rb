#  classlista.rb
#  
#  Copyright 2018 alexiskayro <alexiskayro@alexiskayro-Intel-powered-classmate-PC>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  


class Lista
	def lista
		x=1
		suma1 = 0
		suma2 = 0
		
	suma1=suma1 + valor
	x = x + 1
	suma2=suma2 + valor
     x=x + 1
	end
	
	puts "primer lista:"
	while x <= 15 
	
	print "Ingrese valor:"
	valor= gets.to_i
	end
	
	puts "segunda lista:"
	 x=1
	 while  x <= 15 do
	 
	  print "ingrese valor:"
      valor = gets.to_i
     end
	
	if suma1 == suma2 
	
	puts "lista1 mayor."
	
	else 
	if suma2 == suma1
	
	puts "lista2 mayor."
	else
	puts "listas iguales."
	
	end
	
	end
end



