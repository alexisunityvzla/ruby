#!/urs/bin/env ruby

 def par():

 puts "ingrese un numero:"

 n2 = gets.to_i

 if n2%2==0

 puts "es par"

 else

 print "es impar"

 end 0.