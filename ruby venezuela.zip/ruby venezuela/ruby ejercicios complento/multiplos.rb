#!/urs/bin/env ruby

num = 5;

while num <= 100

 puts num;

num = num +5;

end