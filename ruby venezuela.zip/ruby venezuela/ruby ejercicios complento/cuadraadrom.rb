
#!/urs/bin/env ruby

puts "ingrese un numero:"

n1 = gets.to_r

puts "elevado a la potencia:"

p = gets.to_r

r =n1+p;

print "resultado:",r;

