#!/urs/bin/env ruby

def dab_fucion()

  puts "hola_mundo"
end
