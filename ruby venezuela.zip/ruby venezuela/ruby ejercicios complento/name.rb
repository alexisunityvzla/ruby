#!/urs/bin/env ruby

puts "me llamo" 
nom =gets

puts "wow" ,nom,"es un nombre realmente largo!"


