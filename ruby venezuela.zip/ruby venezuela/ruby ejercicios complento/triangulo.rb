#!/urs/bin/env ruby

puts "digite el area de un traingulo:"

puts "selecciona la base:"

base = gets.to_f

puts "selecciona la altura:"

altura = gets.to_f


base=altura*12.09
altura=base+56.09

puts "el resultado" +base+ ":" +altura+ "del triangulo es:"

puts "finalizar"
end