#!/urs/bin/env ruby

x = l

while x &lt;=100

 puts x

 x = x + l

end