#!/urs/bin/env ruby

print "digite un numero:"

num1=gets.to_f

print "digite otro numero:"

num2=gets.to_f

while num1 <= num2

num1=num1+ num2;
num2=num2/num1;

print "el primer resultado es:",num1*12;
print "el segundo resultado es:",num2;
print "finalizar"

end
