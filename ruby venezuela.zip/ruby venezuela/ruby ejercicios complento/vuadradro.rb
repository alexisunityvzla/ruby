#!/urs/bin/env ruby

puts "digite la forma del cuadradro:"

puts "selecciona numero de forma vertical:"

v1 = gets.to_i

puts "selecciona numero de forma horizontal:"

h2 = gets.to_i

while( v1 <= h2) {

    puts "la forma" + "cuadradro" + "igual"
    
}

puts "resultado del cuadradro es:"
puts "vertical es:"+ v1+"horinzontal es:"+h2+"cuadradro:"
puts "finalizar"

end

