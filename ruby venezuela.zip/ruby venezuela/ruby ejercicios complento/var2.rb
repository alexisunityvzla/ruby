#!/urs/bin/env ruby

puts '15'.to_f
puts '99.999'.to_f
puts '99.999'.to_i
puts '5 es mi numero favorito.'.to_i
puts '¿quien pregunta acerca de 5 o lo que sea?'.to_i
puts 'Tu mama hizo.'.to_f
puts 'fibroso'.to_s

puts 3.to_i