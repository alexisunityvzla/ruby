#!/urs/bin/env ruby

n=5;

puts "instroduzca un numeroS:"
h=gets.to_i
puts "el resultado final es:",h,"el siguente"

puts "el mulltiplos de 100 y 1:"
n=gets.to_i
while n <= 105

puts n
n=n+5;

end
