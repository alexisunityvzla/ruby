#!/urs/bin/env ruby

var1=2
var2='5'

puts var1.to_f + var2
puts var1 + var2.to_i

end