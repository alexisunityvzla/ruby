#!/urs/bin/env ruby

puts mystring
puts mystring
