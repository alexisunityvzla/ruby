#!/urs/bin/env ruby


while num != 0
 puts" instroduzca un numero:"

  num = gets.to_i

if num >= 0

 puts "es par"

else

 puts "es impar"

puts " instroduzca otro numero:"

 num = gets.to_i

  