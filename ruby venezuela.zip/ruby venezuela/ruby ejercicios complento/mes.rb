#!/urs/bin/env ruby

puts "digita un mes si esta correcto o no:"

m1 = gets.to_i

if m1 <= 12

 puts "esta correcto"

else

 puts "no esta correcto"

 puts "finalizar"

end 