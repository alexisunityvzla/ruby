#!/ur/bin/env ruby

print "Ingrese el valor final:"
n=gets.to_i

x=1
while  x <= 100 do

 print x,"-"
 
x= x + 1

end
