#!/urs/bin/env ruby

def dado()

while d1 != 7

  puts "ingrese el numero de dado de siete lado:"

  d1=gets.to_s

  puts "el resultado de los dado es:",d1;


end
end
