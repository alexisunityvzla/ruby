#!/urs/bin/env ruby

puts "hola ¿cual estu nombre?"

name=gets.chomp

puts "¿tu nombre es"+name+"? !esunnombreadorable!"
puts "Encantado de conocerte,"+name+":."