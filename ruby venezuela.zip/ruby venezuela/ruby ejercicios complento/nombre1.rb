# encoding: utf-8

#!/urs/bin/env ruby

puts 20
puts 20.to_s
puts '20'

puts gets

puts "hola,¿cual estu nombre?"
name=gets
puts "¿tu nombre es"+name+"?¡esun nombre adorable!"
puts "Encantador deconocerte,"+name+". :)"


	
end