#!/urs/bin/env ruby

x = l
while x &lt;=100
print x,"_"
x = x + l

end