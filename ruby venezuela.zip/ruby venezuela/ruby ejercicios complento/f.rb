#!/urs/bin/env ruby

for i=0;i<10;i++

	puts n

end
