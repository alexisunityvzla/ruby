#!/urs/bin/ env ruby

puts "Ingrse tu nombre:"

nombre=gets.to_i

if nombre == "alexis" 

 print "hola"

else

 print " no te conozco "
