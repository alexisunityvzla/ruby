#!/urs/bin/env ruby

puts "ingrese primera nota:"
nota1 = gets.to_i
puts "ingrese segunda nota:"
nota2 = gets.to_i
puts "ingrese tercer nota:"
nota3 = gets.to_i

prom = (nota1 + nota2 + nota3)/3

if prom >= 7
    puts "promocionaado"
else
 if prom >= 4
  puts "regular"

  else
  puts "reprobado·

  end
end
