#!/urs/bin/env ruby

puts "soy"+"alexis"