#!/urs/bin/env ruby


conta1=""
conta2=""
x=""
l=""
print "cuantos empleados tiene la empresa:"

n = gets.to_i

while n <= 45
print "Ingrese el sueldo del empleados:"
sueldo = gets
if sueldo <=300

puts conta1 = conta1 + 1

else

puts conta2 = conta2 + 1

end

gastos = gastos + sueldo

x = x + l

puts "cantidad de empleados con sueldos entre 100 y 300:",conta1,"\n"
puts "cantidad de empleados con sueldos mayor a 300:",conta2,"\n"
puts "gastos total de la empresa en sueldos:",gastos;

end
