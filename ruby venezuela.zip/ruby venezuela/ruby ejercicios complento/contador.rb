#!/urs/bin/env ruby

for cc in range(5,1005)

	cc=cc+5;
	cd=cd-5;
	puts "numero_c"+cc+"numero_d"+cd;

	