#!/urs/bin/env ruby

puts "hola_mundo"