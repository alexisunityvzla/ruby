#!/urs/bin/env ruby

x = l
l = 1
conta1 = 0
conta2 = 0

while x <10

 print "Ingrese nota:"
 nota=gets.to_i
if nota >7
 conta1 = conta1+1
else
 conta2 = conta2+1
end

 x = x + l
end

print " cantidad de alumnos con notas mayores o iguales a 7:",conta1,"\n"
print " cantidad de alumnos con notas menores a 7:",conta2
