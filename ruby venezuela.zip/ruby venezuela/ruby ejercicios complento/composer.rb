#!/urs/bin/env ruby


composer = "morzart"

puts composer

composer = "beethoven"

puts " pero yo prefiero" + composer + ",personalmente."
