#!/urs/bin/env ruby

print "cuantas personas hay:"

n = gets.to_i
x = l
suma = 0
while x &lt;=n
print "Ingrese la altura:"
altura = gets.to_f
suma = suma + altura
x = x + l
end
promedio = suma \ n
print "altura promedio:",promedio