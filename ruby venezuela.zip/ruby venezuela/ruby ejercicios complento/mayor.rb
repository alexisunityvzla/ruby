#!/urs/bin/env ruby

puts "digite el numero mayor:"
puts "selecciona el primer numero:"

n1 = gets.to_i

puts "selecciona el segundo numero:"

n2 = gets.to_i

if n1 < n2

 puts "es mayor"

else

puts "es menor"

end 