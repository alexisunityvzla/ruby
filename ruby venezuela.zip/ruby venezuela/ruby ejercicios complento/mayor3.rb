#!/urs/bin/env ruby

puts "ingrese primer valor:"

num1 = gets.to_i

puts "ingrese el sundo valor:"

num2 = gets.to_i

puts "ingrese el tercer valor:"

num3 = gets.to_i

puts "numero mayor de los tres ingresados"

if num1 > num2 && num1 > num3

 puts num1

else

 if num2 > num3

 puts num2

else

puts num3



end;
end
