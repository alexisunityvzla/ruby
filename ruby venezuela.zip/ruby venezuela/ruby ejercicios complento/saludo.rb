#!/urs/bin/envruby

puts "44.4444".to_f
puts "hola"+"como te llama"
puts "Gusto de conocerte"+"alexis"

end
