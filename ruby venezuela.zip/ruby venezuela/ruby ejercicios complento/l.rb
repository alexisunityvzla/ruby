#!/urs/bin/env ruby
 
var = 5*2+2

puts var 

