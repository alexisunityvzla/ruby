#!/urs/bin/env ruby

puts "Ingrese  dos numero 2 digitos:"

n=gets.to_i
rpta=gets.to_i


c=n/10;
c=n%10;
rpta=c+10;

print "el numero reves es:",rpta;

end