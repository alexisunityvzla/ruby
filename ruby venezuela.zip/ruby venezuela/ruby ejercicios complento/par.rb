#!/urs/bin/env ruby 

puts "digite el numero cual es par :"

puts "selecciona un numero:"

if n1%3==0:

puts "es par"

else:

puts "es impar"

puts "finalizar"

end

