#!/urs/bin/env ruby

var = 8
var2 = var1

puts var1
puts var2

puts ""

var1 = "ocho"

puts var1
puts var2

