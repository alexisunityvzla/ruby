#!/urs/bin/env ruby

puts "parpadeo"*4

puts "betty"+12
puts "fred"*"john"