!#/urs/bin/env ruby

puts "digite un numero cualquiera:"

n1=gets.to_i

puts "digite otro numero:"

n2=gets.to_i

print "el resultado final es:,n1+n2"