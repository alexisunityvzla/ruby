#!/urs/bin/env ruby

puts "Ingrese nro de dia:"
dd=gets.to_i
puts "Ingrese nro mes:"
mm=gets.to_i
puts "Ingrese nro año:"
aa=gets.to_i

if mm == 1 || mm == 2 || mm == 3
puts "Corresponde al primer trimestre"

end
