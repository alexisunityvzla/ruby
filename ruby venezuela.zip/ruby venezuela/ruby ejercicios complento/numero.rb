#!/urs/bin/env ruby

puts "numero 1:"
num1 = gets.to_i
puts "numero 2:"
num2 = gets.to_i
RESUL = (num1+num2)*(num1-num2);
puts ""
puts "el resultado es:"+RESUL+""
puts "finalizar"
end