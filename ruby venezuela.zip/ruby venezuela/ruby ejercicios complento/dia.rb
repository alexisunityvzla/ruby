#!/urs/bin/env ruby

puts "ingrese numero de dia:"

dd = gets.to_i

puts "ingrese numero de mes:"

mm = gets.to_i

puts " ingrese numero de año:"

aa = gets.to_i

if mm == 1 || mm == 2 || mm == 3

puts "corresponde al primer trimestre"

end