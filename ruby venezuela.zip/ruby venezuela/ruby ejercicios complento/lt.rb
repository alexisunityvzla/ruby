#!/urs/bin/env ruby

x = 3;
l= 3;
while x <=100
 print x
 print "_"
 x = x + l
end
