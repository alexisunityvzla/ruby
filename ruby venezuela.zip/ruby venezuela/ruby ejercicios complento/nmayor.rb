#!/urs/bin/env ruby


puts "el resultado es"
puts "finalizar"



