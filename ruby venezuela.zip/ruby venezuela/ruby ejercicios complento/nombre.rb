#!/urs/bin/env ruby

puts "hola,¿cual es tu nombre?"

name=gets
puts "¿tu nombre es" + name + "?¡ es un nombre adorable !"
puts  encantador de conocerte," +  name + ".:)"