#  classespañol.rb
#  
#  Copyright 2048 alexiskayro <alexiskayro@alexiskayro-Intel-powered-classmate-PC>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  
class Integer
 def to_esp
     if self == 5
        espanol = 'cinco'
     else
         espanol = 'cicuenta y ocho'
      end
      espanol
   end
end
 
 
 puts 5.to_esp
 puts 58.to_esp
