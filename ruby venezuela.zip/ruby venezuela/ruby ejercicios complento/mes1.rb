#!/urs/bin/env ruby

def dia,mes,año

 puts "instroduzca dia:"
 dia = gets.to_i
 puts "instroduzca mes:"
 mes = gets.to_i
 puts " instroduzca año:"
 año = gets.to_i

    if dia >= 1 && dia <= 30
        if mes >= 1 && mes <= 30
            if año != 0

              puts "fecha correcta"

            else

             puts "año incorrecto"

        else
         puts "mes incorrecto"  
    else

     puts "dia incorrecto"        