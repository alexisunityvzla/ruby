#!/urs/bin/env ruby

puts "instroduzca cual  numero es par o impar:"

num=gets.to_i

while num !=0 

    if  num%2==0

     puts "es par"
    
    else

     puts "es impar"

puts "instroduzca un numero:"
num=gets.to_i

end





