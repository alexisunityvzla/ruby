#!/urs/bin/env ruby

def argc()

 if argc == 0
    puts "Linea de comando no disponible"
    else
      puts "El programa esta corriendo:"+argv[0]+"igual"
    if argc == 1
     puts "Argumento no recibidos en las Linea de comando." 
    else
     puts "Argumento de la Linea de comando:"
   
     puts "argv[i]"

end
end
end
