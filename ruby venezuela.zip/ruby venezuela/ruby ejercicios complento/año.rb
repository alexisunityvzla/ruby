#!/urs/bin/env ruby

puts "Ingrese nro de dia:"
dd=gets.to_i
puts "Ingrese nro de mes:"
mm=gets.to_i
puts "Ingrese nro de año:"
aa=gets.to_i

if mm > 30 && dd < 7 && aa > 3000

	puts "la fecha corresponde a navidad."

end

puts "dia es:",dd;
puts "mes es:",mm;
puts "año es:",aa;
