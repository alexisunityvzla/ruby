#!/urs/bin/env ruby

print "Ingrese el valor final:"

n=gets.to_i
x=l
while x & lt;=n
 print x,"_"
 x = x +l
end